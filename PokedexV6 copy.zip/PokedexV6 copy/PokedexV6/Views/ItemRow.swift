//
//  ItemRow.swift
//  PokedexV6
//
//  Created by Quinn Wienke on 8/23/23.
//

import SwiftUI

struct ItemRow: View {
    
    let pokemonItemRow: Pokemon
    
    var body: some View {
        Text(pokemonItemRow.name)
    }
}

struct ItemRow_Previews: PreviewProvider {
    static var previews: some View {
        ItemRow(pokemonItemRow: Pokemon.example)
    }
}
