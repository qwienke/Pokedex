//
//  DetailPokemonView.swift
//  Pokedexv5
//
//  Created by Quinn Wienke on 8/2/23.
//

import SwiftUI

struct DetailPokemonView: View {
    var imageLink = ""
    let pokemon: PokemonEntry
    let pokemonSprite: PokemonSprites
    var body: some View {
        HStack {
            Text(pokemon.name)
        }
    }
}

struct DetailPokemonView_Previews: PreviewProvider {
    static var previews: some View {
        DetailPokemonView(pokemon: PokemonEntry.example, pokemonSprite: .example)
    }
}
