//
//  ContentView.swift
//  Pokedexv5
//
//  Created by Quinn Wienke on 8/1/23.
//

import SwiftUI

struct ContentView: View {
    @State var pokemon = [PokemonEntry]()
    @State var searchText = ""
    
    var body: some View {
        NavigationView {
            List {
                
                //The forEach loop will  check to see if the searchbar has anything, i fnoot it will return a list of pokemon inside an h stack, where if there is it will do the same with just the pokemon that have characters inside the searh bar. The Htack contains a pokemon image view as well as a navigation link view. The navigationLink will brinf you to a new view controller(The one i want to have populated with the data from PokemonSelected).
                //The entry is taking each entry inside the forEach loop which is creating a Hstack for each pokemon.
                
                //This is checking to see if the searchText has any information in it. If not it returns all the pokemon in the array, if it does then it will return only pokemon with the specefied letters
                ForEach(searchText == "" ? pokemon : pokemon.filter ( {
                    $0.name.contains(searchText.lowercased())
                })) // This is here to show the image as well as the pokemon name and create a navigation link from each pokemon cell and have a detail view that shows infor about the pokemon
                
                ///entry is the pokemon that is selected and then this takes that pokemon and appends the url in order to get the image info?
                
                { entry in
                    HStack {
                        PokemonImage(imageLink: "\(entry.url)") //For each entry in the HStack, take the pokemonImage with the imageLink of the cells assigned pokemon.
                            .padding(.trailing, 20)
                        NavigationLink("\(entry.name)".capitalized, destination: PokemonImageDetailView(imageLink: "\(entry.url)", pokemon: entry))
                        
                        //In the navigationLink take the tapped pokemon and
                    }
                }
            }
            //Whenever this view is called it needs to reload the data returned from the pokeApi
            .onAppear {
                //It will call the original API in order to get a list of all the pokemon and then is run thoruhg a completion listner. Each pokemon ran through that completion listenter is then going to be added to a new array
                PokeApi().getData() { pokemon in
                    self.pokemon = pokemon
                }
            }
            //Create a search bar that takes in the searchText variable from above
            .searchable(text: $searchText)
            .navigationTitle("Pokedex")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

