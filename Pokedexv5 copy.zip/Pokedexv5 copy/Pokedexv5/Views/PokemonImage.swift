//
//  PokemonImage.swift
//  Pokedexv5
//
//  Created by Quinn Wienke on 8/1/23.
//

import SwiftUI

struct PokemonImage: View {
    //These 2 vars are creating varialbe to save the link needed from the api for the image and the pokemonSprite is taking
    var imageLink = ""
    @State private var pokemonSprite = ""
    
    var body: some View {
        AsyncImage(url: URL(string: pokemonSprite))
            .frame(width: 75, height: 75)
        //Create a request so that its not needed to ask for new urls every time data reloads, and just use the old urls. To do this we are just going ot save the URLs
            .onAppear {
                let loadedData = UserDefaults.standard.string(forKey: imageLink)
                
                if loadedData == nil {
                    getSprite(url: imageLink)
                    UserDefaults.standard.set(imageLink, forKey: imageLink)
                    print("New url caching")
                } else {
                    getSprite(url: loadedData!)
                    print("Using cached URL")
                }
            }
            .clipShape(Circle())
            .foregroundColor(Color.gray.opacity(0.60))
    }
    
    func getSprite(url: String) {
        var tempSprite: String?
        
        PokemonSelectedApi().getData(url: url) { sprite in
            tempSprite = sprite.front_default
            //Above is taking the tempSprite and assigning it the front_default from the API in order to get the image info. Below it is assigning type pokemonSprite to the url taken from tempSprite else just show a placeholder
            self.pokemonSprite = tempSprite ?? "placeholder"
        }
    }
}

struct PokemonImage_Previews: PreviewProvider {
    static var previews: some View {
        PokemonImage()
    }
}
