//
//  Pokedexv5App.swift
//  Pokedexv5
//
//  Created by Quinn Wienke on 8/1/23.
//

import SwiftUI

@main
struct Pokedexv5App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
