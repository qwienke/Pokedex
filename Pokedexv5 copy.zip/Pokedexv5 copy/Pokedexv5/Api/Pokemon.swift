//
//  Pokemon.swift
//  Pokedexv5
//
//  Created by Quinn Wienke on 8/1/23.
//

//Create the api call to get the info for ... and then we will have to create a second call going a layer deeper grabbing the info for sprites etc

import Foundation

struct Pokemon: Codable {
    var results: [PokemonEntry]
}
// This grabs the results from the api going a layer deeper the PokemonEntry struct then grabs the name and URL from inside the results

struct PokemonEntry: Codable, Identifiable, Hashable {
    var id: String {
        return url
    }
    var name: String
    var url: String
    
    static let example = PokemonEntry(name: "pikachu", url: "https://pokeapi.co/api/v2/pokemon?1imit=151")
}

class PokeApi {
    func getData(completion: @escaping ([PokemonEntry]) -> ()) {
        // if there is results for a URL it will be the APIs if not then return out of statement
        guard let url = URL(string: "https://pokeapi.co/api/v2/pokemon?1imit=151") else {
            return
        }
        
        URLSession.shared.dataTask(with: url) { (data, _, _) in
            guard let data = data else { return }
            
            //This takes the JSON data represented by 'data' and decodes it into the Pokemon object.
            ///The decode(_:from:) is provided from the JSONDecoder , which is an intance of the JSONDecoder class and is used to parse JSON data. The method takes in 2 arguments. The first being the type you want to decode into, in this case the Pokemon.self, meaning that the JSON data is then going to be decoded into a Pokemon object. The second argument is the data that needs to be decoded.
            
            do {
                let pokemonList = try JSONDecoder().decode(Pokemon.self, from: data)
                DispatchQueue.main.async {
                    completion(pokemonList.results)
                }
            } catch {
                print(error)
            }
            
            
        }.resume()
    }
}
//This API will be able to create an array  for the pokemon in swift, inside this list it returns an id a name and a URL. The URL is what we want in order to get more information on the individual pokemon.
