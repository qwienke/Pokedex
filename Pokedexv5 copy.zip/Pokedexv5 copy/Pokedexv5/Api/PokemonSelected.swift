//
//  PokemonSelected.swift
//  Pokedexv5
//
//  Created by Quinn Wienke on 8/1/23.
//

import Foundation

//This api is taking the specefic URL that is returned from the PokeApi.


///Just help explaning how it works, what does the
/// ItemRow_Previews: PreviewProvider { static var previews: some View {
/// do and how can I use it for what I am tryig to do. Why is the example needed? What can I replace it with? Or how can I add the sprites into it.

struct PokemonSelected: Codable, Hashable, Identifiable {
    var sprites: PokemonSprites?
    
    var id: Int8
    
    
    static let example = PokemonSelected(id: 23)

}

struct PokemonSprites: Codable, Hashable {
    var front_default: String?
    
    static let example = PokemonSprites()
}

class PokemonSelectedApi {
    
    //This is the same as the PokeApi created in Pokemon, But there are a few hanges that are needed to be made
    //First change is addind this url argument inside getData and have it as type string in order to pass in the custom URL that is returned from PokeApi in order to get info on the specific pokemon.
    func getData(url: String, completion: @escaping (PokemonSprites) -> ()) {
        //The url^ is then passed into url below in order to get back the cutom url that has been created
        guard let url = URL(string: url) else { return }
        
        URLSession.shared.dataTask(with: url) { (data, _, _) in
            guard let data = data else { return }
            
            //This takes the JSON data represented by 'data' and decodes it into the Pokemon object.
            ///The decode(_:from:) is provided from the JSONDecoder , which is an intance of the JSONDecoder class and is used to parse JSON data. The method takes in 2 arguments. The first being the type you want to decode into, in this case the PokemonSelected.self, meaning that the JSON data is then going to be decoded into a PokemonSprite object. The second argument is the data that needs to be decoded.
            let pokemonSprite = try! JSONDecoder().decode(PokemonSelected.self, from: data)
            
            DispatchQueue.main.async {
                completion(pokemonSprite.sprites!)
            }
        }.resume()
    }
}
//So now this should be taking the pokemon that is selected and then reaching to the api and returning the url for the sprite image
